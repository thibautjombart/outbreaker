#ifndef __COMMON_H
#include "common.h"
#endif

#ifndef __INIT_H
#define __INIT_H

void CalculIsInHosp(nb_data *, raw_data *);

void InitAugData(parameters *, nb_data * , raw_data *, aug_data *);

void InitMCMCSettings(mcmcInternals *);

void InitParam(parameters *param);

#endif

