#ifndef __COMMON_H
#include "common.h"
#endif

#ifndef __MCMC_H
#define __MCMC_H

void metro (mcmcInternals * , parameters * , raw_data *, nb_data *, aug_data *, acceptance *, isAcceptOK *, NbProposals *, output_files * );

#endif
