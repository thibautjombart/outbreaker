#ifndef __COMMON_H
#include "common.h"
#endif

#ifndef __MOVES_H
#define __MOVES_H

void moveBeta(int, int, mcmcInternals *, parameters *, parameters *, raw_data *, nb_data *, aug_data *, dna_dist *, acceptance *, NbProposals *);

void moveAllBeta(mcmcInternals * , parameters *, parameters * , raw_data * , nb_data *, aug_data *, dna_dist *, acceptance *, NbProposals *);

void moveBetaOut(char, mcmcInternals * , parameters *, parameters * , raw_data * , nb_data *, aug_data *, dna_dist *, acceptance *, NbProposals *);

void moveSe(parameters * , parameters *, raw_data * , nb_data *, aug_data *, acceptance *);

void movePi(parameters * , parameters *, raw_data * , aug_data *, acceptance *);

void moveDurationColon(char, mcmcInternals * , parameters *, parameters * , raw_data * , aug_data *, acceptance *, NbProposals *);

void moveNu(mcmcInternals * MCMCSettings, parameters *, parameters * curParam, raw_data * data, nb_data *nb, aug_data *augData, dna_dist *dnainfo, acceptance *accept, NbProposals *NbProp);

void moveKappa(mcmcInternals * MCMCSettings, parameters *, parameters * curParam, raw_data * data, nb_data *nb, aug_data *augData, dna_dist *dnainfo, acceptance *accept, NbProposals *NbProp);

void moveTau(mcmcInternals * , parameters *, parameters * , raw_data * , nb_data *, aug_data *, dna_dist *, acceptance *, NbProposals *);

void moveAlpha(mcmcInternals * , parameters *, parameters * , raw_data * , nb_data *, aug_data *, dna_dist *, acceptance *, NbProposals *);

void moveC(int, mcmcInternals * , parameters * , raw_data * , nb_data *, aug_data *, aug_data *, dna_dist *);

void moveE(int, mcmcInternals * , parameters *, raw_data * , nb_data *, aug_data *, aug_data *, dna_dist *);

void moveCandE(int, mcmcInternals * , parameters *, raw_data * , nb_data *, aug_data *, aug_data *, dna_dist *);


#endif
